const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');

class QRCodeService {
  
  // Generate QR code for TCC verification with enhanced data
  async generateTCCQRCode(tccData) {
    try {
      const {
        tcc_number,
        taxpayer_full_name,
        taxpayer_tin,
        tax_amount,
        tax_type,
        issue_date,
        expiry_date,
        business_name
      } = tccData;

      // Enhanced verification data
      const verificationData = {
        tcc_number: tcc_number,
        taxpayer_info: {
          full_name: taxpayer_full_name,
          tin: taxpayer_tin,
          business_name: business_name || 'Not Specified'
        },
        tax_details: {
          amount: tax_amount,
          type: tax_type,
          currency: 'ETB'
        },
        certificate_dates: {
          issued: issue_date,
          expires: expiry_date
        },
        verification: {
          url: `${process.env.QR_CODE_BASE_URL || 'http://localhost:3000/verify-tcc'}/${tcc_number}`,
          timestamp: new Date().toISOString(),
          authority: 'Ethiopian Ministry of Revenue'
        },
        status: 'VALID'
      };

      // Generate QR code as data URL
      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(verificationData), {
        width: 150,
        margin: 1,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      return qrCodeDataURL;

    } catch (error) {
      console.error('QR code generation error:', error);
      return this.generatePlaceholderQRCode();
    }
  }

  // Generate placeholder QR code if real generation fails
  generatePlaceholderQRCode() {
    return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgdmlld0JveD0iMCAwIDE1MCAxNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjE1MCIgaGVpZ2h0PSIxNTAiIGZpbGw9IiNmZmZmZmYiLz48dGV4dCB4PSI3NSIgeT0iNzUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMiIgZmlsbD0iIzAwMDAwMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSI+UVIgQ29kZTwvdGV4dD48L3N2Zz4=';
  }
}

module.exports = new QRCodeService();