const express = require('express');
const cors = require('cors');
const pool = require('./config/database');
const authRoutes = require('./routes/auth');
const applicationRoutes = require('./routes/applications');
const staffRoutes = require('./routes/staff');
const taxRoutes = require('./routes/tax');
const adminRoutes = require('./routes/admin');
const staffReceiptReviewRoutes = require('./routes/staffReceiptReview');
const verificationRoutes = require('./routes/verification');
const staffStampsRoutes = require('./routes/staffStamps');
const verifyRoutes = require('./routes/verify');
const regionalAdminRoutes = require('./routes/regionalAdmin');
const townAdminRoutes = require('./routes/townAdmin');
const publicRoutes = require('./routes/public');
const townRoutes = require('./routes/town');

require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static('uploads'));
app.use('/api/verify', verificationRoutes);
// Routes
app.use('/api/auth', authRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/tax', taxRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/staff', staffReceiptReviewRoutes);
app.use('/api/staff', staffStampsRoutes);
app.use('/api/verify', verifyRoutes);
app.use('/api/admin', regionalAdminRoutes);
app.use('/api/town', townAdminRoutes);
app.use('/api/public', publicRoutes);
app.use('/api/town', townRoutes);
app.use('/uploads', express.static('uploads'));
// Basic route for testing
app.get('/', (req, res) => {
  res.json({ 
    message: '🇪🇹 Tax Clearance System API is running!',
    timestamp: new Date().toISOString(),
    status: 'Active'
  });
});

// Health check route
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK',
    service: 'Tax Clearance Backend',
    time: new Date().toISOString()
  });
});

// Database test route
app.get('/api/test-db', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW() as current_time, version() as postgres_version');
    res.json({
      database: 'Connected successfully!',
      currentTime: result.rows[0].current_time,
      postgresVersion: result.rows[0].postgres_version
    });
  } catch (error) {
    console.error('Database connection error:', error);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server is running on port ${PORT}`);
  console.log(`📍 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🗄️  Database test: http://localhost:${PORT}/api/test-db`);
  console.log(`🔐 Auth routes: http://localhost:${PORT}/api/auth`);
});