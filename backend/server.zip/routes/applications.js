const express = require('express');
const pool = require('../config/database');
const auth = require('../middleware/auth');

const router = express.Router();

// Helper function to generate certificate for an application
async function generateCertificateForApplication(applicationId) {
  try {
    console.log('🔄 Generating certificate for application:', applicationId);
    
    const applicationDetails = await pool.query(
      `SELECT ta.*, u.full_name, u.tin, u.business_name, u.email, u.phone, 
              u.region_id, u.town_id, r.name as region_name, t.name as town_name
       FROM tcc_applications ta 
       JOIN users u ON ta.user_id = u.id 
       LEFT JOIN regions r ON u.region_id = r.id
       LEFT JOIN towns t ON u.town_id = t.id
       WHERE ta.id = $1 AND ta.status = 'Approved'`,
      [applicationId]
    );

    if (applicationDetails.rows.length === 0) {
      throw new Error('Application not found or not approved');
    }

    const application = applicationDetails.rows[0];
    
    // Generate TCC number
    const tccNumber = `TCC-${new Date().getFullYear()}-${String(applicationId).padStart(6, '0')}`;
    const issueDate = new Date();
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);

    const certificateData = {
      tcc_number: tccNumber,
      issue_date: issueDate,
      expiry_date: expiryDate
    };

    const taxpayerData = {
      full_name: application.full_name,
      tin: application.tin,
      business_name: application.business_name,
      email: application.email,
      phone: application.phone,
      region_name: application.region_name,
      town_name: application.town_name
    };

    // Import the PDF service
    const { generateTCCCertificate } = require('../services/pdfService');
    
    // Generate PDF
    const pdfBuffer = await generateTCCCertificate(certificateData, taxpayerData, application);

    // Save certificate
    await pool.query(
      `INSERT INTO issued_certificates 
       (application_id, tcc_number, issue_date, expiry_date, pdf_data) 
       VALUES ($1, $2, $3, $4, $5)`,
      [applicationId, tccNumber, issueDate, expiryDate, pdfBuffer]
    );

    console.log('✅ Certificate generated successfully for application:', applicationId);
    return true;
    
  } catch (error) {
    console.error('❌ Certificate generation failed:', error);
    throw error;
  }
}

// Get all applications for logged-in taxpayer
router.get('/my-applications', auth, async (req, res) => {
  try {
    const applications = await pool.query(
      `SELECT 
        ta.id, 
        ta.status, 
        ta.submitted_at, 
        ta.reviewed_at,
        ta.rejection_reason,
        ta.region_id,
        ta.town_id,
        r.name as region_name,
        t.name as town_name,
        u.full_name as reviewed_by_name
       FROM tcc_applications ta
       LEFT JOIN users u ON ta.reviewed_by = u.id
       LEFT JOIN regions r ON ta.region_id = r.id
       LEFT JOIN towns t ON ta.town_id = t.id
       WHERE ta.user_id = $1 
       ORDER BY ta.submitted_at DESC`,
      [req.user.user_id]
    );

    res.json({
      applications: applications.rows
    });

  } catch (error) {
    console.error('Get applications error:', error);
    res.status(500).json({ error: 'Failed to fetch applications' });
  }
});

// Submit new TCC application
router.post('/', auth, async (req, res) => {
  try {
    // Check if user already has a pending application
    const pendingApp = await pool.query(
      'SELECT id FROM tcc_applications WHERE user_id = $1 AND status IN ($2, $3)',
      [req.user.user_id, 'Submitted', 'Under Review']
    );

    if (pendingApp.rows.length > 0) {
      return res.status(400).json({ 
        error: 'You already have a pending TCC application. Please wait for it to be processed.' 
      });
    }

    // Get user details including region and town
    const userResult = await pool.query(
      'SELECT region_id, town_id FROM users WHERE id = $1',
      [req.user.user_id]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userResult.rows[0];

    // Create new application with region and town data
    const newApplication = await pool.query(
      `INSERT INTO tcc_applications (user_id, status, region_id, town_id) 
       VALUES ($1, 'Submitted', $2, $3) 
       RETURNING *`,
      [req.user.user_id, user.region_id, user.town_id]
    );

    res.status(201).json({
      message: 'TCC application submitted successfully',
      application: newApplication.rows[0]
    });

  } catch (error) {
    console.error('Submit application error:', error);
    res.status(500).json({ error: 'Failed to submit application' });
  }
});

// Download TCC certificate for taxpayer
router.get('/:id/certificate', auth, async (req, res) => {
  try {
    const certificate = await pool.query(
      `SELECT ic.*, ta.user_id, u.full_name, u.tin, u.email, u.phone, u.business_name,
              u.region_id, u.town_id, r.name as region_name, t.name as town_name
       FROM issued_certificates ic
       JOIN tcc_applications ta ON ic.application_id = ta.id
       JOIN users u ON ta.user_id = u.id
       LEFT JOIN regions r ON u.region_id = r.id
       LEFT JOIN towns t ON u.town_id = t.id
       WHERE ta.id = $1 AND ta.user_id = $2`,
      [req.params.id, req.user.user_id]
    );

    if (certificate.rows.length === 0) {
      return res.status(404).json({ error: 'Certificate not found or not approved' });
    }

    const cert = certificate.rows[0];

    // Check if PDF data exists
    if (!cert.pdf_data) {
      return res.status(404).json({ error: 'PDF certificate not generated yet' });
    }

    // Set headers for PDF download
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="TCC-${cert.tcc_number}.pdf"`);
    
    // Send the PDF buffer directly
    res.send(cert.pdf_data);

  } catch (error) {
    console.error('Download certificate error:', error);
    res.status(500).json({ error: 'Failed to download certificate' });
  }
});

// Add endpoint to manually trigger certificate generation (for testing/admin purposes)
router.post('/:id/generate-certificate', auth, async (req, res) => {
  try {
    // Check if user owns this application
    const application = await pool.query(
      'SELECT * FROM tcc_applications WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.user_id]
    );

    if (application.rows.length === 0) {
      return res.status(404).json({ error: 'Application not found' });
    }

    if (application.rows[0].status !== 'Approved') {
      return res.status(400).json({ error: 'Application must be approved to generate certificate' });
    }

    // Check if certificate already exists
    const existingCert = await pool.query(
      'SELECT * FROM issued_certificates WHERE application_id = $1',
      [req.params.id]
    );

    if (existingCert.rows.length > 0) {
      return res.status(400).json({ error: 'Certificate already exists for this application' });
    }

    // Generate certificate
    await generateCertificateForApplication(req.params.id);

    res.json({
      message: 'Certificate generated successfully',
      application_id: req.params.id
    });

  } catch (error) {
    console.error('Manual certificate generation error:', error);
    res.status(500).json({ error: 'Failed to generate certificate: ' + error.message });
  }
});

module.exports = router;