const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../config/database');
const auth = require('../middleware/auth');

const router = express.Router();

// Middleware to check if user is super admin
const requireSuperAdmin = (req, res, next) => {
  if (!req.user.is_super_admin) {
    return res.status(403).json({ error: 'Access denied. Super admin role required.' });
  }
  next();
};

// Get all regions
router.get('/regions', auth, requireSuperAdmin, async (req, res) => {
  try {
    const regions = await pool.query('SELECT * FROM regions ORDER BY name');
    res.json({ regions: regions.rows });
  } catch (error) {
    console.error('Get regions error:', error);
    res.status(500).json({ error: 'Failed to fetch regions' });
  }
});

// Create new region
router.post('/regions', auth, requireSuperAdmin, async (req, res) => {
  try {
    const { name, code, target_tax_amount } = req.body;
    
    const newRegion = await pool.query(
      'INSERT INTO regions (name, code, target_tax_amount, created_by) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, code, target_tax_amount, req.user.user_id]
    );

    res.json({ region: newRegion.rows[0] });
  } catch (error) {
    console.error('Create region error:', error);
    res.status(500).json({ error: 'Failed to create region' });
  }
});

// Get all towns
router.get('/towns', auth, requireSuperAdmin, async (req, res) => {
  try {
    const towns = await pool.query(
      `SELECT t.*, r.name as region_name,
       (SELECT COUNT(*) FROM users u WHERE u.town_id = t.id AND u.user_type = 'town_admin') as town_admins_count
       FROM towns t
       LEFT JOIN regions r ON t.region_id = r.id
       ORDER BY r.name, t.name`
    );
    res.json({ towns: towns.rows });
  } catch (error) {
    console.error('Get towns error:', error);
    res.status(500).json({ error: 'Failed to fetch towns' });
  }
});

// Create new town
router.post('/towns', auth, requireSuperAdmin, async (req, res) => {
  try {
    const { region_id, name, code, target_tax_amount } = req.body;
    
    const newTown = await pool.query(
      'INSERT INTO towns (region_id, name, code, target_tax_amount, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [region_id, name, code, target_tax_amount, req.user.user_id]
    );

    res.json({ town: newTown.rows[0] });
  } catch (error) {
    console.error('Create town error:', error);
    res.status(500).json({ error: 'Failed to create town' });
  }
});

// Assign regional/town admin
router.post('/assign-admin', auth, requireSuperAdmin, async (req, res) => {
  try {
    const { email, password, full_name, region_id, town_id, assignment_type } = req.body;
    
    // Check if user already exists
    const existingUser = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email already exists' });
    }

    // Hash password
    const saltRounds = 10;
    const password_hash = await bcrypt.hash(password, saltRounds);

    // Determine user type and set region/town IDs
    let userType, finalRegionId, finalTownId;
    
    if (assignment_type === 'regional_admin') {
      userType = 'regional_admin';
      finalRegionId = region_id;
      finalTownId = null;
    } else {
      userType = 'town_admin';
      finalRegionId = region_id;
      finalTownId = town_id;
    }

    const newUser = await pool.query(
      `INSERT INTO users (full_name, email, password_hash, user_type, region_id, town_id) 
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, full_name, email, user_type, region_id, town_id`,
      [full_name, email, password_hash, userType, finalRegionId, finalTownId]
    );

    // Record admin assignment
    await pool.query(
      `INSERT INTO admin_assignments (user_id, assigned_region_id, assigned_town_id, assigned_by, assignment_type) 
       VALUES ($1, $2, $3, $4, $5)`,
      [newUser.rows[0].id, region_id, town_id, req.user.user_id, assignment_type]
    );

    res.json({ 
      message: `${assignment_type.replace('_', ' ')} assigned successfully`,
      admin: newUser.rows[0]
    });

  } catch (error) {
    console.error('Assign admin error:', error);
    res.status(500).json({ error: 'Failed to assign admin' });
  }
});

// Get regional admins
router.get('/regional-admins', auth, requireSuperAdmin, async (req, res) => {
  try {
    const admins = await pool.query(
      `SELECT u.*, r.name as region_name
       FROM users u
       LEFT JOIN regions r ON u.region_id = r.id
       WHERE u.user_type = 'regional_admin'
       ORDER BY r.name, u.full_name`
    );
    res.json({ admins: admins.rows });
  } catch (error) {
    console.error('Get regional admins error:', error);
    res.status(500).json({ error: 'Failed to fetch regional admins' });
  }
});
// Get towns by region ID
router.get('/towns-by-region/:regionId', auth, async (req, res) => {
  try {
    const towns = await pool.query(
      `SELECT t.*, r.name as region_name
       FROM towns t
       LEFT JOIN regions r ON t.region_id = r.id
       WHERE t.region_id = $1 AND t.is_active = true
       ORDER BY t.name`,
      [req.params.regionId]
    );
    res.json({ towns: towns.rows });
  } catch (error) {
    console.error('Get towns by region error:', error);
    res.status(500).json({ error: 'Failed to fetch towns' });
  }
});

// Get town admins
router.get('/town-admins', auth, requireSuperAdmin, async (req, res) => {
  try {
    const admins = await pool.query(
      `SELECT u.*, r.name as region_name, t.name as town_name
       FROM users u
       LEFT JOIN regions r ON u.region_id = r.id
       LEFT JOIN towns t ON u.town_id = t.id
       WHERE u.user_type = 'town_admin'
       ORDER BY r.name, t.name, u.full_name`
    );
    res.json({ admins: admins.rows });
  } catch (error) {
    console.error('Get town admins error:', error);
    res.status(500).json({ error: 'Failed to fetch town admins' });
  }
});

// Get regional statistics
router.get('/regional-stats', auth, requireSuperAdmin, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        r.name as region_name,
        r.target_tax_amount,
        COALESCE(SUM(tp.paid_amount), 0) as collected_tax_amount,
        COUNT(DISTINCT u.id) as total_taxpayers,
        COUNT(DISTINCT tp.id) as total_payments,
        COUNT(DISTINCT ta.id) as total_tcc_applications
      FROM regions r
      LEFT JOIN towns t ON r.id = t.region_id
      LEFT JOIN users u ON t.id = u.town_id
      LEFT JOIN tax_payments tp ON u.id = tp.user_id AND tp.payment_status = 'completed'
      LEFT JOIN tcc_applications ta ON u.id = ta.user_id
      GROUP BY r.id, r.name, r.target_tax_amount
      ORDER BY r.name
    `);

    res.json({ stats: stats.rows });
  } catch (error) {
    console.error('Get regional stats error:', error);
    res.status(500).json({ error: 'Failed to fetch regional statistics' });
  }
});

module.exports = router;