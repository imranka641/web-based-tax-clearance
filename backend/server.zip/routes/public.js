const express = require('express');
const pool = require('../config/database');

const router = express.Router();

// Get all active regions (public route for registration)
router.get('/regions', async (req, res) => {
  try {
    const regions = await pool.query(
      'SELECT * FROM regions WHERE is_active = true ORDER BY name'
    );
    res.json({ regions: regions.rows });
  } catch (error) {
    console.error('Get regions error:', error);
    res.status(500).json({ error: 'Failed to fetch regions' });
  }
});

// Get towns by region ID (public route for registration)
router.get('/towns-by-region/:regionId', async (req, res) => {
  try {
    const towns = await pool.query(
      `SELECT t.*, r.name as region_name
       FROM towns t
       LEFT JOIN regions r ON t.region_id = r.id
       WHERE t.region_id = $1 AND t.is_active = true
       ORDER BY t.name`,
      [req.params.regionId]
    );
    res.json({ towns: towns.rows });
  } catch (error) {
    console.error('Get towns by region error:', error);
    res.status(500).json({ error: 'Failed to fetch towns' });
  }
});

module.exports = router;