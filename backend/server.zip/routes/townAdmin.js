const express = require('express');
const pool = require('../config/database');
const auth = require('../middleware/auth');

const router = express.Router();

// Middleware to check if user is town admin
const requireTownAdmin = (req, res, next) => {
  if (req.user.user_type !== 'town_admin') {
    return res.status(403).json({ error: 'Access denied. Town admin role required.' });
  }
  next();
};

// Get town statistics
router.get('/stats', auth, requireTownAdmin, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        t.name as town_name,
        r.name as region_name,
        COUNT(DISTINCT u.id) as total_taxpayers,
        COUNT(DISTINCT ta.id) as total_applications,
        COUNT(DISTINCT ta.id) FILTER (WHERE ta.status = 'Submitted') as pending_applications,
        COUNT(DISTINCT tp.id) as total_payments,
        COALESCE(SUM(tp.paid_amount), 0) as collected_tax
      FROM towns t
      LEFT JOIN regions r ON t.region_id = r.id
      LEFT JOIN users u ON t.id = u.town_id AND u.user_type = 'taxpayer'
      LEFT JOIN tcc_applications ta ON u.id = ta.user_id
      LEFT JOIN tax_payments tp ON u.id = tp.user_id AND tp.payment_status = 'completed'
      WHERE t.id = $1
      GROUP BY t.id, t.name, r.name
    `, [req.user.town_id]);

    res.json(stats.rows[0] || {});
  } catch (error) {
    console.error('Get town stats error:', error);
    res.status(500).json({ error: 'Failed to fetch town statistics' });
  }
});

// Get TCC applications for town
router.get('/tcc-applications', auth, requireTownAdmin, async (req, res) => {
  try {
    const applications = await pool.query(
      `SELECT 
        ta.*,
        u.full_name as taxpayer_name,
        u.tin as taxpayer_tin,
        u.email as taxpayer_email,
        u.business_name
       FROM tcc_applications ta
       JOIN users u ON ta.user_id = u.id
       WHERE ta.town_id = $1
       ORDER BY ta.submitted_at DESC`,
      [req.user.town_id]
    );

    res.json({ applications: applications.rows });
  } catch (error) {
    console.error('Get town applications error:', error);
    res.status(500).json({ error: 'Failed to fetch applications' });
  }
});

// Get recent payments for town
router.get('/recent-payments', auth, requireTownAdmin, async (req, res) => {
  try {
    const payments = await pool.query(
      `SELECT 
        tp.*,
        u.full_name as taxpayer_name,
        tt.name as tax_type_name
       FROM tax_payments tp
       JOIN users u ON tp.user_id = u.id
       LEFT JOIN tax_types tt ON tp.tax_type_id = tt.id
       WHERE u.town_id = $1
       ORDER BY tp.payment_date DESC
       LIMIT 10`,
      [req.user.town_id]
    );

    res.json({ payments: payments.rows });
  } catch (error) {
    console.error('Get town payments error:', error);
    res.status(500).json({ error: 'Failed to fetch payments' });
  }
});

module.exports = router;