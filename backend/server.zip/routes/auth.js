const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer'); // ADD THIS
const path = require('path'); // ADD THIS
const { body, validationResult } = require('express-validator');
const pool = require('../config/database');

const router = express.Router();

// ========== MULTER CONFIGURATION FOR NATIONAL ID UPLOADS ==========

// Configure multer for national ID uploads
const nationalIdStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/national_ids/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'national-id-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const uploadNationalId = multer({ 
  storage: nationalIdStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|pdf/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only JPEG, PNG, and PDF files are allowed'));
    }
  }
});

// ========== REGISTRATION ROUTE WITH FILE UPLOAD ==========

router.post('/register', uploadNationalId.single('national_id'), [
  body('full_name').notEmpty().withMessage('Full name is required'),
  body('tin').notEmpty().withMessage('TIN is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('region_id').notEmpty().withMessage('Region is required'),
  body('town_id').notEmpty().withMessage('Town is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { 
      full_name, 
      tin, 
      email, 
      password, 
      phone, 
      business_name, 
      fayda_number,
      region_id,
      town_id 
    } = req.body;

    // Check if user already exists
    const userExists = await pool.query(
      'SELECT * FROM users WHERE email = $1 OR tin = $2',
      [email, tin]
    );

    if (userExists.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email or TIN already exists' });
    }

    // Hash password
    const saltRounds = 10;
    const password_hash = await bcrypt.hash(password, saltRounds);

    // Use uploaded file path if file exists
    const nationalIdFilePath = req.file ? req.file.path : null;

    // Insert new user with all fields
    const newUser = await pool.query(
      `INSERT INTO users (full_name, tin, email, password_hash, phone, business_name, fayda_number, region_id, town_id, national_id_file_path, user_type) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'taxpayer') 
       RETURNING id, full_name, tin, email, phone, business_name, fayda_number, region_id, town_id, user_type`,
      [full_name, tin, email, password_hash, phone, business_name, fayda_number, region_id, town_id, nationalIdFilePath]
    );

    // Create taxpayer compliance record
    await pool.query(
      `INSERT INTO taxpayer_records (tin, has_filed_returns, has_paid_taxes, outstanding_balance) 
       VALUES ($1, true, true, 0.00)`,
      [tin]
    );

    // Generate JWT token
    const token = jwt.sign(
      { 
        user_id: newUser.rows[0].id, 
        email: newUser.rows[0].email,
        user_type: newUser.rows[0].user_type
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: newUser.rows[0]
    });

  } catch (error) {
    console.error('Registration error details:', error);
    res.status(500).json({ error: 'Registration failed: ' + error.message });
  }
});

// ========== LOGIN ROUTE (Keep your existing login) ==========

router.post('/login', [
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').exists().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;

    // Find user
    const userResult = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );

    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const user = userResult.rows[0];

    // Check password
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        user_id: user.id, 
        email: user.email,
        user_type: user.user_type,
        role: user.role, // This should be 'staff'
         is_super_admin: user.is_super_admin || false  // Include this!
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        full_name: user.full_name,
        tin: user.tin,
        email: user.email,
        phone: user.phone,
        business_name: user.business_name,
        role: user.role, // This should be 'staff'
        user_type: user.user_type,
        region_id: user.region_id,
        town_id: user.town_id,
         is_super_admin: user.is_super_admin || false  // Include this!
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

module.exports = router;