const express = require('express');
const pool = require('../config/database');

const router = express.Router();

// Verify TCC by QR code
router.get('/tcc/:tccNumber', async (req, res) => {
  try {
    const { tccNumber } = req.params;

    const tccData = await pool.query(
      `SELECT 
        ic.*,
        u.full_name as taxpayer_full_name,
        u.tin as taxpayer_tin,
        u.business_name,
        tt.name as tax_type_name
       FROM issued_certificates ic
       JOIN users u ON ic.taxpayer_id = u.id
       LEFT JOIN tax_types tt ON ic.tax_type_id = tt.id
       WHERE ic.tcc_number = $1`,
      [tccNumber]
    );

    if (tccData.rows.length === 0) {
      return res.status(404).json({ error: 'TCC not found or invalid' });
    }

    const certificate = tccData.rows[0];

    // Enhanced verification response
    const verificationResponse = {
      tcc_number: certificate.tcc_number,
      taxpayer_full_name: certificate.taxpayer_full_name,
      taxpayer_tin: certificate.taxpayer_tin,
      business_name: certificate.business_name,
      tax_amount: certificate.tax_amount,
      tax_type: certificate.tax_type_name,
      issue_date: certificate.issue_date,
      expiry_date: certificate.expiry_date,
      status: new Date(certificate.expiry_date) > new Date() ? 'VALID' : 'EXPIRED',
      verification: {
        timestamp: new Date().toISOString(),
        authority: 'Ethiopian Ministry of Revenue',
        verified: true
      }
    };

    res.json(verificationResponse);

  } catch (error) {
    console.error('TCC verification error:', error);
    res.status(500).json({ error: 'Verification failed' });
  }
});

module.exports = router;