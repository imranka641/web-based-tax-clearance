import React from 'react';
import { Navbar, Nav, Container, Badge } from 'react-bootstrap';
import { getToken, getUser } from '../../utils/auth';

const Navigation = () => {
  const token = getToken();
  const user = getUser();

  return (
    <Navbar bg="primary" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand href="/">
          🇪🇹 Ethiopian Tax Clearance System
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {token ? (
              <>
                {/* Super Admin Dashboard - Visible to all logged in users */}
                <Nav.Link href="/admin/dashboard" className="text-warning">
                  ⚡ Super Admin
                </Nav.Link>
                
                {/* Staff Dashboards - Visible to all logged in users */}
                <Nav.Link href="/staff-dashboard" className="text-white">
                  📊 Staff Dashboard
                </Nav.Link>
                <Nav.Link href="/staff/receipt-review" className="text-white">
                  📄 Review Receipts
                </Nav.Link>
                <Nav.Link href="/staff/stamp-management" className="text-white">
                  🖋️ My Stamp
                </Nav.Link>
                
                {/* Regional Admin Dashboard - Visible to all logged in users */}
                <Nav.Link href="/regional-dashboard" className="text-white">
                  🌍 Regional Dashboard
                </Nav.Link>
                
                {/* Town Admin Dashboard - Visible to all logged in users */}
                <Nav.Link href="/town-dashboard" className="text-white">
                  🏙️ Town Dashboard
                </Nav.Link>
                
                {/* Taxpayer Dashboards - Visible to all logged in users */}
                <Nav.Link href="/dashboard" className="text-white">
                  📋 TCC Applications
                </Nav.Link>
                <Nav.Link href="/tax/dashboard" className="text-white">
                  💰 Pay Taxes
                </Nav.Link>
                <Nav.Link href="/tax/history" className="text-white">
                  📈 Payment History
                </Nav.Link>
                <Nav.Link href="/tax/deadlines" className="text-white">
                  📅 Deadlines
                </Nav.Link>
                
                {/* Common links for all authenticated users */}
                <Nav.Link href="/tax/profile" className="text-white">
                  👤 Profile
                </Nav.Link>
                
                <Nav.Link href="/logout" className="text-white">
                  🚪 Logout 
                  <Badge bg="light" text="dark" className="ms-2">
                    {user?.full_name}
                  </Badge>
                </Nav.Link>
              </>
            ) : (
              <>
                <Nav.Link href="/login" className="text-white">
                  🔐 Login
                </Nav.Link>
                <Nav.Link href="/register" className="text-white">
                  📝 Register
                </Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navigation;