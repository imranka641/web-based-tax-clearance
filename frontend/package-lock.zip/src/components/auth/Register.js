import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Form, Button, Alert, Spinner } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import api from '../../services/api';
import { setToken, setUser } from '../../utils/auth';

const Register = () => {
  const [regions, setRegions] = useState([]);
  const [towns, setTowns] = useState([]);
  const [townsLoading, setTownsLoading] = useState(false);
  const [nationalIdFile, setNationalIdFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    full_name: '',
    tin: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    business_name: '',
    fayda_number: '',
    region_id: '',
    town_id: ''
  });

  useEffect(() => {
    fetchRegions();
  }, []);

  const fetchRegions = async () => {
    try {
      const response = await api.get('/public/regions');
      setRegions(response.data.regions);
    } catch (error) {
      console.error('Error fetching regions:', error);
    }
  };

  const fetchTownsByRegion = async (regionId) => {
    try {
      setTownsLoading(true);
      const response = await api.get(`/public/towns-by-region/${regionId}`);
      setTowns(response.data.towns);
    } catch (error) {
      console.error('Error fetching towns:', error);
      setTowns([]);
    } finally {
      setTownsLoading(false);
    }
  };

  const handleRegionChange = async (e) => {
    const regionId = e.target.value;
    setFormData(prev => ({
      ...prev,
      region_id: regionId,
      town_id: '' // Reset town when region changes
    }));

    if (regionId) {
      await fetchTownsByRegion(regionId);
    } else {
      setTowns([]);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNationalIdUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (!validTypes.includes(file.type)) {
        setError('Please upload JPEG, PNG, or PDF files only');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setError('File size must be less than 5MB');
        return;
      }
      setNationalIdFile(file);
    }
  };

const onSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);
  setError('');

  // FIX: Access from formData object
  if (formData.password !== formData.confirmPassword) {
    setError('Passwords do not match');
    setLoading(false);
    return;
  }

  // Log form data for debugging
  console.log('Registration data:', formData);
  console.log('National ID file:', nationalIdFile);

  try {
    // Create FormData object for file upload
    const formDataObj = new FormData();
    formDataObj.append('full_name', formData.full_name);
    formDataObj.append('tin', formData.tin);
    formDataObj.append('email', formData.email);
    formDataObj.append('password', formData.password);
    formDataObj.append('phone', formData.phone);
    formDataObj.append('business_name', formData.business_name);
    formDataObj.append('fayda_number', formData.fayda_number);
    formDataObj.append('region_id', formData.region_id);
    formDataObj.append('town_id', formData.town_id);
    
    if (nationalIdFile) {
      formDataObj.append('national_id', nationalIdFile);
    }

    const response = await api.post('/auth/register', formDataObj, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });

    const { token, user } = response.data;
    
    // Store token and user data
    setToken(token);
    setUser(user);
    
    navigate('/dashboard');

  } catch (err) {
    console.error('Registration error:', err);
    console.error('Error response:', err.response?.data);
    setError(err.response?.data?.error || 'Registration failed. Please try again.');
  } finally {
    setLoading(false);
  }
};

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <Card className="shadow">
            <Card.Header className="bg-success text-white text-center">
              <h4 className="mb-0">Create Taxpayer Account</h4>
            </Card.Header>
            <Card.Body className="p-4">
              {error && <Alert variant="danger">{error}</Alert>}
              
              <Form onSubmit={onSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Full Name *</Form.Label>
                      <Form.Control
                        type="text"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>TIN (Taxpayer Identification Number) *</Form.Label>
                      <Form.Control
                        type="text"
                        name="tin"
                        value={formData.tin}
                        onChange={handleInputChange}
                        placeholder="Enter your TIN"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Email Address *</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter your email"
                    required
                  />
                </Form.Group>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Password *</Form.Label>
                      <Form.Control
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        placeholder="Enter password (min. 6 characters)"
                        minLength="6"
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Confirm Password *</Form.Label>
                      <Form.Control
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                        placeholder="Confirm your password"
                        minLength="6"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Phone Number</Form.Label>
                  <Form.Control
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="+251 XXX XXX XXX"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Business Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="business_name"
                    value={formData.business_name}
                    onChange={handleInputChange}
                    placeholder="Enter your business name"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Fayda Number</Form.Label>
                  <Form.Control
                    type="text"
                    name="fayda_number"
                    value={formData.fayda_number}
                    onChange={handleInputChange}
                    placeholder="Enter your Fayda number"
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Region *</Form.Label>
                  <Form.Select
                    name="region_id"
                    value={formData.region_id}
                    onChange={handleRegionChange}
                    required
                  >
                    <option value="">Select Region</option>
                    {regions.map(region => (
                      <option key={region.id} value={region.id}>{region.name}</option>
                    ))}
                  </Form.Select>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Town *</Form.Label>
                  <Form.Select
                    name="town_id"
                    value={formData.town_id}
                    onChange={handleInputChange}
                    required
                    disabled={!formData.region_id || townsLoading}
                  >
                    <option value="">Select Town</option>
                    {townsLoading ? (
                      <option value="" disabled>Loading towns...</option>
                    ) : (
                      towns.map(town => (
                        <option key={town.id} value={town.id}>{town.name}</option>
                      ))
                    )}
                  </Form.Select>
                  {townsLoading && (
                    <div className="mt-2">
                      <Spinner animation="border" size="sm" /> Loading towns...
                    </div>
                  )}
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>National ID Document *</Form.Label>
                  <Form.Control
                    type="file"
                    accept=".jpg,.jpeg,.png,.pdf"
                    onChange={handleNationalIdUpload}
                    required
                  />
                  <Form.Text className="text-muted">
                    Upload clear image/PDF of your National ID (Max 5MB)
                  </Form.Text>
                </Form.Group>

                <div className="d-grid">
                  <Button 
                    variant="success" 
                    type="submit" 
                    disabled={loading}
                    size="lg"
                  >
                    {loading ? (
                      <>
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden="true"
                          className="me-2"
                        />
                        Creating Account...
                      </>
                    ) : (
                      'Create Account'
                    )}
                  </Button>
                </div>
              </Form>

              <div className="text-center mt-3">
                <p className="mb-0">
                  Already have an account? <Link to="/login">Login here</Link>
                </p>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Register;