import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Table, Button, Form, Modal, Badge, Alert } from 'react-bootstrap';
import api from '../../../services/api';

const RegionalManagement = () => {
  const [regions, setRegions] = useState([]);
  const [towns, setTowns] = useState([]);
  const [regionalAdmins, setRegionalAdmins] = useState([]);
  const [townAdmins, setTownAdmins] = useState([]);
  const [showRegionModal, setShowRegionModal] = useState(false);
  const [showTownModal, setShowTownModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const [regionForm, setRegionForm] = useState({
    name: '',
    code: '',
    target_tax_amount: ''
  });

  const [townForm, setTownForm] = useState({
    region_id: '',
    name: '',
    code: '',
    target_tax_amount: ''
  });

  const [adminForm, setAdminForm] = useState({
    email: '',
    password: '',
    full_name: '',
    region_id: '',
    town_id: '',
    assignment_type: 'regional_admin'
  });

  useEffect(() => {
    fetchRegionalData();
  }, []);

  const fetchRegionalData = async () => {
    try {
      const [regionsRes, townsRes, regionalAdminsRes, townAdminsRes] = await Promise.all([
        api.get('/admin/regions'),
        api.get('/admin/towns'),
        api.get('/admin/regional-admins'),
        api.get('/admin/town-admins')
      ]);

      setRegions(regionsRes.data.regions);
      setTowns(townsRes.data.towns);
      setRegionalAdmins(regionalAdminsRes.data.admins);
      setTownAdmins(townAdminsRes.data.admins);
    } catch (error) {
      console.error('Error fetching regional data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createRegion = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/regions', regionForm);
      setShowRegionModal(false);
      setRegionForm({ name: '', code: '', target_tax_amount: '' });
      fetchRegionalData();
    } catch (error) {
      console.error('Error creating region:', error);
    }
  };

  const createTown = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/towns', townForm);
      setShowTownModal(false);
      setTownForm({ region_id: '', name: '', code: '', target_tax_amount: '' });
      fetchRegionalData();
    } catch (error) {
      console.error('Error creating town:', error);
    }
  };

  const createAdmin = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/assign-admin', adminForm);
      setShowAdminModal(false);
      setAdminForm({ 
        email: '', 
        password: '', 
        full_name: '', 
        region_id: '', 
        town_id: '', 
        assignment_type: 'regional_admin' 
      });
      fetchRegionalData();
    } catch (error) {
      console.error('Error creating admin:', error);
    }
  };

  const getProgressPercentage = (collected, target) => {
    if (!target || target === 0) return 0;
    return Math.min(100, (collected / target) * 100);
  };

  const getProgressVariant = (percentage) => {
    if (percentage >= 100) return 'success';
    if (percentage >= 75) return 'info';
    if (percentage >= 50) return 'warning';
    return 'danger';
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4>Regional & Town Management</h4>
        <div>
          <Button variant="primary" className="me-2" onClick={() => setShowRegionModal(true)}>
            + Add Region
          </Button>
          <Button variant="success" className="me-2" onClick={() => setShowTownModal(true)}>
            + Add Town
          </Button>
          <Button variant="warning" onClick={() => setShowAdminModal(true)}>
            + Assign Admin
          </Button>
        </div>
      </div>

      <Row>
        {/* Regions Overview */}
        <Col md={6}>
          <Card className="shadow-sm mb-4">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">Regions Overview</h5>
            </Card.Header>
            <Card.Body>
              {regions.map(region => (
                <Card key={region.id} className="mb-3">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-start">
                      <div>
                        <h6>{region.name} ({region.code})</h6>
                        <p className="mb-1">
                          <strong>Target:</strong> ETB {region.target_tax_amount?.toLocaleString()}
                        </p>
                        <p className="mb-1">
                          <strong>Collected:</strong> ETB {region.collected_tax_amount?.toLocaleString()}
                        </p>
                        <div className="mt-2">
                          <div className="progress" style={{ height: '10px' }}>
                            <div 
                              className={`progress-bar bg-${getProgressVariant(getProgressPercentage(region.collected_tax_amount, region.target_tax_amount))}`}
                              style={{ width: `${getProgressPercentage(region.collected_tax_amount, region.target_tax_amount)}%` }}
                            ></div>
                          </div>
                          <small className="text-muted">
                            {getProgressPercentage(region.collected_tax_amount, region.target_tax_amount).toFixed(1)}% Complete
                          </small>
                        </div>
                      </div>
                      <Badge bg={region.is_active ? 'success' : 'secondary'}>
                        {region.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </Card.Body>
                </Card>
              ))}
            </Card.Body>
          </Card>
        </Col>

        {/* Towns and Admins */}
        <Col md={6}>
          {/* Towns List */}
          <Card className="shadow-sm mb-4">
            <Card.Header className="bg-success text-white">
              <h5 className="mb-0">Towns</h5>
            </Card.Header>
            <Card.Body>
              {towns.map(town => (
                <div key={town.id} className="border-bottom pb-2 mb-2">
                  <div className="d-flex justify-content-between">
                    <div>
                      <strong>{town.name}</strong>
                      <small className="d-block text-muted">
                        Region: {town.region_name} | Target: ETB {town.target_tax_amount?.toLocaleString()}
                      </small>
                    </div>
                    <Badge bg="info">{town.town_admins_count || 0} Admins</Badge>
                  </div>
                </div>
              ))}
            </Card.Body>
          </Card>

          {/* Regional Admins */}
          <Card className="shadow-sm mb-4">
            <Card.Header className="bg-warning text-dark">
              <h5 className="mb-0">Regional Admins</h5>
            </Card.Header>
            <Card.Body>
              {regionalAdmins.map(admin => (
                <div key={admin.id} className="border-bottom pb-2 mb-2">
                  <div className="d-flex justify-content-between">
                    <div>
                      <strong>{admin.full_name}</strong>
                      <small className="d-block text-muted">{admin.email}</small>
                      <small>Region: {admin.region_name}</small>
                    </div>
                    <Badge bg="primary">Regional</Badge>
                  </div>
                </div>
              ))}
            </Card.Body>
          </Card>

          {/* Town Admins */}
          <Card className="shadow-sm">
            <Card.Header className="bg-info text-white">
              <h5 className="mb-0">Town Admins</h5>
            </Card.Header>
            <Card.Body>
              {townAdmins.map(admin => (
                <div key={admin.id} className="border-bottom pb-2 mb-2">
                  <div className="d-flex justify-content-between">
                    <div>
                      <strong>{admin.full_name}</strong>
                      <small className="d-block text-muted">{admin.email}</small>
                      <small>Town: {admin.town_name} | Region: {admin.region_name}</small>
                    </div>
                    <Badge bg="success">Town</Badge>
                  </div>
                </div>
              ))}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Add Region Modal */}
      <Modal show={showRegionModal} onHide={() => setShowRegionModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Region</Modal.Title>
        </Modal.Header>
        <Form onSubmit={createRegion}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Region Name *</Form.Label>
              <Form.Control
                type="text"
                value={regionForm.name}
                onChange={(e) => setRegionForm({...regionForm, name: e.target.value})}
                placeholder="e.g., Amhara, Oromia, Tigray"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Region Code *</Form.Label>
              <Form.Control
                type="text"
                value={regionForm.code}
                onChange={(e) => setRegionForm({...regionForm, code: e.target.value})}
                placeholder="e.g., AM, OR, TI"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Target Tax Amount (ETB) *</Form.Label>
              <Form.Control
                type="number"
                value={regionForm.target_tax_amount}
                onChange={(e) => setRegionForm({...regionForm, target_tax_amount: e.target.value})}
                placeholder="10000000"
                required
                step="0.01"
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowRegionModal(false)}>
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              Create Region
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Add Town Modal */}
      <Modal show={showTownModal} onHide={() => setShowTownModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Town</Modal.Title>
        </Modal.Header>
        <Form onSubmit={createTown}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Select Region *</Form.Label>
              <Form.Select
                value={townForm.region_id}
                onChange={(e) => setTownForm({...townForm, region_id: e.target.value})}
                required
              >
                <option value="">Select Region</option>
                {regions.map(region => (
                  <option key={region.id} value={region.id}>{region.name}</option>
                ))}
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Town Name *</Form.Label>
              <Form.Control
                type="text"
                value={townForm.name}
                onChange={(e) => setTownForm({...townForm, name: e.target.value})}
                placeholder="e.g., Bahir Dar, Mekelle, Adama"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Town Code *</Form.Label>
              <Form.Control
                type="text"
                value={townForm.code}
                onChange={(e) => setTownForm({...townForm, code: e.target.value})}
                placeholder="e.g., BD, MK, AD"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Target Tax Amount (ETB)</Form.Label>
              <Form.Control
                type="number"
                value={townForm.target_tax_amount}
                onChange={(e) => setTownForm({...townForm, target_tax_amount: e.target.value})}
                placeholder="500000"
                step="0.01"
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowTownModal(false)}>
              Cancel
            </Button>
            <Button variant="success" type="submit">
              Create Town
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Assign Admin Modal */}
      <Modal show={showAdminModal} onHide={() => setShowAdminModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Assign Regional/Town Admin</Modal.Title>
        </Modal.Header>
        <Form onSubmit={createAdmin}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Admin Type *</Form.Label>
              <Form.Select
                value={adminForm.assignment_type}
                onChange={(e) => setAdminForm({...adminForm, assignment_type: e.target.value})}
                required
              >
                <option value="regional_admin">Regional Admin</option>
                <option value="town_admin">Town Admin</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Full Name *</Form.Label>
              <Form.Control
                type="text"
                value={adminForm.full_name}
                onChange={(e) => setAdminForm({...adminForm, full_name: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email *</Form.Label>
              <Form.Control
                type="email"
                value={adminForm.email}
                onChange={(e) => setAdminForm({...adminForm, email: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password *</Form.Label>
              <Form.Control
                type="password"
                value={adminForm.password}
                onChange={(e) => setAdminForm({...adminForm, password: e.target.value})}
                required
              />
            </Form.Group>
            {adminForm.assignment_type === 'regional_admin' && (
              <Form.Group className="mb-3">
                <Form.Label>Assign to Region *</Form.Label>
                <Form.Select
                  value={adminForm.region_id}
                  onChange={(e) => setAdminForm({...adminForm, region_id: e.target.value})}
                  required
                >
                  <option value="">Select Region</option>
                  {regions.map(region => (
                    <option key={region.id} value={region.id}>{region.name}</option>
                  ))}
                </Form.Select>
              </Form.Group>
            )}
            {adminForm.assignment_type === 'town_admin' && (
              <>
                <Form.Group className="mb-3">
                  <Form.Label>Select Region *</Form.Label>
                  <Form.Select
                    value={adminForm.region_id}
                    onChange={(e) => {
                      setAdminForm({
                        ...adminForm, 
                        region_id: e.target.value,
                        town_id: '' // Reset town when region changes
                      });
                    }}
                    required
                  >
                    <option value="">Select Region</option>
                    {regions.map(region => (
                      <option key={region.id} value={region.id}>{region.name}</option>
                    ))}
                  </Form.Select>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Select Town *</Form.Label>
                  <Form.Select
                    value={adminForm.town_id}
                    onChange={(e) => setAdminForm({...adminForm, town_id: e.target.value})}
                    required
                    disabled={!adminForm.region_id}
                  >
                    <option value="">Select Town</option>
                    {towns
                      .filter(town => town.region_id == adminForm.region_id)
                      .map(town => (
                        <option key={town.id} value={town.id}>{town.name}</option>
                      ))
                    }
                  </Form.Select>
                </Form.Group>
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowAdminModal(false)}>
              Cancel
            </Button>
            <Button variant="warning" type="submit">
              Assign Admin
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};

export default RegionalManagement;