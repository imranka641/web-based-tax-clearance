import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/common/Navigation';
import Login from './components/auth/Login';
import Logout from './components/auth/Logout'; 
import Register from './components/auth/Register';
import TaxpayerDashboard from './components/dashboard/TaxpayerDashboard';
import TCCApplication from './components/dashboard/TCCApplication';
import StaffDashboard from './components/staff/StaffDashboard';
import ApplicationReview from './components/staff/ApplicationReview';
import TaxPaymentDashboard from './components/tax/TaxPaymentDashboard';
import EnhancedTaxPaymentForm from './components/tax/EnhancedTaxPaymentForm';
import TaxDeadlines from './components/tax/TaxDeadlines';
import PaymentHistory from './components/tax/PaymentHistory';
import TaxCalculator from './components/tax/TaxCalculator';
import TaxProfile from './components/tax/TaxProfile';
import SuperAdminDashboard from './components/admin/SuperAdminDashboard';
import ReceiptReviewQueue from './components/staff/ReceiptReviewQueue';
import ReceiptReviewDetail from './components/staff/ReceiptReviewDetail';
import QRVerification from './components/verification/QRVerification';
import StaffStampManagement from './components/staff/StaffStampManagement';
import VerifyTCC from './components/VerifyTCC';
import TownDashboard from './components/town/TownDashboard';

import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />
        
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<TaxpayerDashboard />} />
          <Route path="/apply-tcc" element={<TCCApplication />} />
          <Route path="/staff-dashboard" element={<StaffDashboard />} />
          <Route path="/staff/applications/:id" element={<ApplicationReview />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/tax/dashboard" element={<TaxPaymentDashboard />} />
          <Route path="/tax/pay/:taxTypeId" element={<EnhancedTaxPaymentForm />} />
          <Route path="/tax/deadlines" element={<TaxDeadlines />} />
          <Route path="/tax/history" element={<PaymentHistory />} />
          <Route path="/tax/calculator" element={<TaxCalculator />} />
          <Route path="/tax/profile" element={<TaxProfile />} />
          <Route path="/admin/dashboard" element={<SuperAdminDashboard />} />
          <Route path="/staff/receipt-review" element={<ReceiptReviewQueue />} />
          <Route path="/staff/receipt-review/:paymentId" element={<ReceiptReviewDetail />} />
          <Route path="/verify-tcc/:tccNumber" element={<QRVerification />} />
          <Route path="/staff/stamp-management" element={<StaffStampManagement />} />
<Route path="/verify-tcc/:tccNumber" element={<VerifyTCC />} />
<Route path="/town-dashboard" element={<TownDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

// Homepage component
const HomePage = () => (
  <div className="container mt-5">
    <div className="row justify-content-center">
      <div className="col-md-8">
        <div className="card shadow">
          <div className="card-header bg-success text-white text-center">
            <h3 className="mb-0">Welcome to Tax Clearance System</h3>
            <small>Ministry of Revenue - Ethiopia</small>
          </div>
          <div className="card-body">
            <p className="lead text-center">
              Streamlining tax compliance verification and certificate issuance through digital innovation.
            </p>
            
            <div className="row mt-4">
              <div className="col-md-6 mb-3">
                <div className="card h-100 border-primary">
                  <div className="card-body text-center">
                    <h5 className="card-title text-primary">For Taxpayers</h5>
                    <p className="card-text">
                      Apply for Tax Clearance Certificates online, track your application status, and download digital certificates.
                    </p>
                    <a href="/login" className="btn btn-primary">Taxpayer Login</a>
                  </div>
                </div>
              </div>
              <div className="col-md-6 mb-3">
                <div className="card h-100 border-success">
                  <div className="card-body text-center">
                    <h5 className="card-title text-success">For Ministry Staff</h5>
                    <p className="card-text">
                      Review applications, verify taxpayer compliance, and issue digital certificates efficiently.
                    </p>
                    <a href="/login" className="btn btn-success">Staff Login</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default App;